---
bylines: 'Daniel Murphy'
capi: '9c28557636ba9cf52ef23806f361b301'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/RICH_KIDS/RICH_KIDS.html'
slug: '/20-rich-kids'
tech: 'Adobe Animate CC'
thumb: ''
title: '20 Rich kids under 20'
---
