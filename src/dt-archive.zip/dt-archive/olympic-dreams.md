---
bylines: ''
capi: 'dd3ea79ba18bbc7e1bc5942b09eb1b7b'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/olympicdreams/index.html'
slug: '/olympic-dreams'
tech: ''
thumb: ''
title: 'Olympic dreams'
---
