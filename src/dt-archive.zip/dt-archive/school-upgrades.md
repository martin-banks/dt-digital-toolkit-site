---
bylines: ''
capi: '0f7ce07676c1f0ea816d046ae1334be0'
date: ''
description: ''
preview: 'https://www.onlyfuzz.com/DTinteractives/school/index.html'
slug: '/school-upgrades'
tech: ''
thumb: ''
title: 'School upgrades'
---
