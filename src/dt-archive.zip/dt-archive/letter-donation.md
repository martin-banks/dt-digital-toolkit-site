---
bylines: ''
capi: 'a0a2832f8fa8f628eb0a4bcc09b3f1b6'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/Letterfordonation/index.html'
slug: '/letter-donation'
tech: 'Jpg'
thumb: ''
title: 'Paul and Cathies appeal for a donor embryo'
---
