---
bylines: ''
capi: '1842de4958ce30cb04e3697ce6c47b8f'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/droughtwatersolution/index.html'
slug: '/drought-water'
tech: ''
thumb: ''
title: 'Our drinking water tastes like dirt'
---
