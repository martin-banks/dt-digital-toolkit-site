---
bylines: 'Candy Luan'
capi: '5ff9c5e48308d783dcf86614cf836e4b'
date: ''
description: "Executive chefs setting up kitchen in the state's clubs and RSLs"
preview: 'https://media.news.com.au/DTinteractive/Chefsclub/index.html'
slug: '/rsl-chefs'
tech: ''
thumb: ''
title: 'RSL Chefs'
---
