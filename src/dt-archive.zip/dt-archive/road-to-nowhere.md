---
bylines: ''
capi: 'e4535f71fc33f219d8d7c4068db0c421'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/roadtonowhere/index.html'
slug: '/road-to-nowhere'
tech: 'Jpg'
thumb: ''
title: 'Road to nowhere'
---
