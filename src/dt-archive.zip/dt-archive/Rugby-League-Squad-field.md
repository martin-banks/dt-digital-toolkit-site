---
bylines: 'Daniel Murphy'
capi: '6524e6f43ad1f849855972c33a66823e'
date: ''
description: 'Rugby League Team Squad'
preview: 'https://media.news.com.au/DTinteractive/KANGAROOS/index.html'
slug: '/rugby-league-squad'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Kangaroo Team List'
---