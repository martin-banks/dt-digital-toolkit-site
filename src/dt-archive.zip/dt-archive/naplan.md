---
bylines: ''
capi: '5b95cba446bdc35b12501f9b6d7df23b'
date: ''
description: 'A selection of schools that scored aove average gains in numeracy or reading'
preview: 'https://media.news.com.au/DTinteractive/NAPLAN_MAP/index.html'
slug: '/naplan-stats'
tech: ''
thumb: ''
title: 'Naplan stats'
---
