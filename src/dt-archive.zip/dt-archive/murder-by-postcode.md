---
bylines: ''
capi: '6030eaa50e2da991eac8befc6f910eb5'
date: '2018-08-08'
description: ''
preview: 'https://media.news.com.au/DTinteractive/POSTCODES/index.html'
slug: '/dt-190808-postcodes'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Murder by postcode'
---
