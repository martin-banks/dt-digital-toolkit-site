---
bylines: 'Martin Banks, Irene Sclavos'
capi: '01da58865cef341e9c2daba21ed3a887'
date: '2019-03-11'
description: 'SuperCoach NRL editor Tom Sangster looks at the class of 2019 and picks who he thinks will be the top 50 players be the end of the season.'
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2019/ned-0156-supercoach-top50-players-0315/dist/PROD/b2a8a2c83ef51a25082af9c5e8f069f4.html'
slug: '/20190311-aupercoach-top-50'
tech: 'Vue.js'
thumb: ''
title: "SuperCoach's 2019 Top 50"
---
