---
bylines: 'Martin Banks, Irene Sclavos'
capi: ''
date: '2018-09-27'
description: ''
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2018/0926-dna-dallym-team/dist/PROD/preview.html'
slug: '/20180927-dallym-team'
tech: 'Vue.js'
thumb: ''
title: 'Dally M: 2018 Team of the year'
---
