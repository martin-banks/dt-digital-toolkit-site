---
bylines: ''
capi: 'c7a87490e4711e083e2efb9a34a9647d'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/eyespy/index.html'
slug: '/covert-ops'
tech: 'covert-ops'
thumb: ''
title: 'Covert ops'
---
