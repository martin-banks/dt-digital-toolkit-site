---
bylines: 'Fuzz Hamzah'
capi: '384e37568b1c07aeafc91d6ddf2e4820'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/pw/index.html'
slug: '/pub-barons'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Pub barons, who owns what'
---
