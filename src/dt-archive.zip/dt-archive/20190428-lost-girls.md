---
bylines: 'Helen Tsitouris'
capi: 'aaa7b65e437d5f075856e96d5cd6e58f'
date: '2019-04-28'
description: ''
preview: 'https://media.news.com.au/DTinteractive/lostgirls/index.html'
slug: '/20190428-lost-girls'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Lost girls'
---
