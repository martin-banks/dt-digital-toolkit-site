---
bylines: 'Martin Banks, Irene Sclavos'
capi: ''
date: '2018-06-19'
description: 'Last season some of the biggest names left their NRL clubs to start afresh in a new playing strip. Some of them have been huge successes while others have failed to fire. Here are the best and worst of season 2018, so far.'
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2018/0619-nrl-best-buys/_BUILD/PROD/preview.html'
slug: '/20180619-nrl-htis-and-misses'
tech: 'JavaScript'
thumb: ''
title: 'Hits and misses of 2018'
---
