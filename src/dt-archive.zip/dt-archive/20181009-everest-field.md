---
bylines: 'Martin Banks, Irene Sclavos'
capi: ''
date: '2018-10-09'
description: ''
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2018/1003-dna-everest-horses/dist/PROD/preview.html'
slug: '/20181009-everest-field'
tech: 'Vue.js'
thumb: ''
title: 'Meet the full everest field'
---
