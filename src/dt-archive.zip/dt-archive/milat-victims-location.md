---
bylines: 'Daniel Murphy'
capi: 'bb8aef3a41496af46c68b02e63694593'
date: ''
description: 'Map of victim locations in Milat murders' 
preview: 'https://media.news.com.au/DTinteractive/MILAT_MURDER_TRAIL/index.html'
slug: '/milat-vitims'
tech: 'Adobe Animate CC'
thumb: ''
title: "Milat's Murder Trail"
---