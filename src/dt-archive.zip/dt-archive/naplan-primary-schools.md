---
bylines: ''
capi: '11aa06ef79c1977e65466eff4586cbfa'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/naplanpri/index.html'
slug: '/naplan-primary-stats'
tech: 'Tumult Hype'
thumb: ''
title: 'Naplan primary school stats'
---
