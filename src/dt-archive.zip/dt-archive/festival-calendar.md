---
bylines: ''
capi: '332215da68fdea4d48795ce637974ba4'
date: ''
description: ''
preview: 'https://onlyfuzz.com/DTinteractives/cal2019/index.html'
slug: '/festival-calendar'
tech: 'Adobe Animate CC'
thumb: ''
title: '2019 Multicultural festival calendar'
---
