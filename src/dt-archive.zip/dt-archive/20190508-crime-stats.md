---
bylines: 'Martin Banks'
capi: '5483a903c2256fe1faa915ec38a171c3'
date: '2019-05-08'
description: 'Explore the stats for all types of crime across NSW and filter to find the stats of your own LGA'
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2019/ned-0285-nsw-suburb-crime-stats-phase1/dist/PROD/efcf37e0a1f720e2bc56dfcb8fa0caea.html'
slug: '/20190508-crime-stats'
tech: 'Vue.js, chart.js'
thumb: ''
title: 'How much crime is in your neighbourhood?'
---
