---
bylines: ''
capi: 'b5ecab9a25e77ca332ec68221d96027b'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/ham3/index.html  '
slug: '/hamzy'
tech: ''
thumb: ''
title: 'Hamzy'
---
