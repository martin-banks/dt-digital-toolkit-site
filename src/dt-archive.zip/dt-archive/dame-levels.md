---
bylines: 'Fuzz Hamzah'
capi: '438489482194f3657b153f7d96b8a373'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/dams/index.html'
slug: '/dam-levels'
tech: 'Tumlt Hype'
thumb: ''
title: 'Dam levels'
---
