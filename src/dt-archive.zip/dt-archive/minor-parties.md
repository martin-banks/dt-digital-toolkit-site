---
bylines: ''
capi: 'c9b83c00340b8373118448df64ec73ff'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/Australianparties/index.html'
slug: '/minor-parties'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Minor parties, major players?'
---
