---
bylines: 'Fabrizio Fiorito'
capi: '48a7ceaff6042e0d39253b4abbc4db67'
date: '2019-08-08'
description: 'The main players from Hate Mail, a book detailing the 20-year story involving a Penthouse Pet, a TV host and two attempted trials.'
preview: 'https://media.news.com.au/DTinteractive/DT-20190808-HATE-MAIL-EXTRACT/kurator-preview.html'
slug: '/dt-20190808-hate-mail'
tech: 'Kurator editorial tools'
thumb: ''
title: 'Hate mail; the main players'
---
