---
bylines: ''
capi: '7e1454b591691da771f95b839165cbd4'
date: ''
description: ''
preview: ''
slug: '/sentiment-tracker'
tech: ''
thumb: ''
title: 'Sentiment tracker'
---
