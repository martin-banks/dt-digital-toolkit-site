---
bylines: 'Daniel Murphy'
capi: '48c42ec4cd0de76a4989c7f2bcdd3bff'
date: ''
description: 'Western Sydney Roads project'
preview: 'https://media.news.com.au/DTinteractive/Orbital/index.html'
slug: '/western-sydney-roads'
tech: ''
thumb: ''
title: 'Western Sydney Orbital'
---