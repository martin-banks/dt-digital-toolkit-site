---
bylines: ''
capi: '2883ef0cb5175c5dcf0aee498f4796ca'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/ibrahimtapes/index.html'
slug: '/ibrahim-tapes/'
tech: ''
thumb: ''
title: 'Ibrahim tapes'
---
