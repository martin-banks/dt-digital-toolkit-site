---
bylines: 'Martin Banks'
capi: '031ad98f23c22cd4813670bd73c40ca0'
date: '2019-04-12'
description: "Complete guide to every showbag avaialble at 2019's Sydney Easter Show. Find hte bags you're after by filtering categories and price points"
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2019/ned-0437-dt-easter-showbags/dist/PROD/preview.html'
slug: '/20190412-showbags'
tech: 'Vue.js'
thumb: ''
title: 'Sydney Easter show showbag guide'
---
