---
bylines: 'Candy Luan'
capi: '954f97a8615c1078caee92b152d36528'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/anewbrandme/index.html'
slug: '/brand-new-me'
tech: 'Adobe Animate CC'
thumb: ''
title: 'A brand new me'
---
