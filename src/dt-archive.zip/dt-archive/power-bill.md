---
bylines: ''
capi: '873d3622d8224cab60e725fcdae79a22'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/powerbill/index.html'
slug: '/power-bill'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Power bills'
---
