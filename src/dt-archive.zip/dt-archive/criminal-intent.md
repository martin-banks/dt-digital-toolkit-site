---
bylines: ''
capi: 'c2f1450266faee6d47d5c95ec85fb213'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/criminalintent/index.html'
slug: '/criminal-intent'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Criminal intent'
---
