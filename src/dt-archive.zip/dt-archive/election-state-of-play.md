---
bylines: ''
capi: '444635fbce5d84a371d549f86a314589'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/ozvotes/index.html'
slug: '/election-state-of-play'
tech: ''
thumb: ''
title: 'Election: state of play'
---
