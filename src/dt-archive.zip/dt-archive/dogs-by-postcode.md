---
bylines: ''
capi: '72eb781520e58059920533f28fe0ad4d'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/dogscouncil/index.html '
slug: '/dogs-by-postcode'
tech: ''
thumb: ''
title: 'Dogs by postcode'
---
