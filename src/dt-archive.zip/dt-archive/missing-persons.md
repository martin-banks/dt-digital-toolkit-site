---
bylines: ''
capi: 'e7023aaf831fe53fc43df101163df380'
date: ''
description: ''
preview: 'http://media01.couriermail.com.au/multimedia/multitools/preview.html?id=1533286178252&mobile=false&type=slider&data=https://multitools.newscdn.com.au/multitools/slider/content/1533286178252/1533286178252-jsonp.js&js=https://multitools.newscdn.com.au/multitools/slider/default/nca-slide-d.js&cb=1556953338589'
slug: '/missing-persons'
tech: 'Multi-tools slider'
thumb: ''
title: 'Missing persons'
---
