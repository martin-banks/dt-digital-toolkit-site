---
bylines: 'Daniel Murphy'
capi: '89d2c8e1e6d8dafa5cf12be1da4a8914'
date: ''
description: 'Regional Fast Train times compared'
preview: 'https://media.news.com.au/DTinteractive/FAST_RAIL/index.html'
slug: '/regional-fast-trains'
tech: ''
thumb: ''
title: 'Regional Fast Trains'
---