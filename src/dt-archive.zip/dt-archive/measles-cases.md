---
bylines: 'Fuzz Hamzah'
capi: 'c61887f56bdfb686ad375ade2c435e7d'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/measles/index.html '
slug: '/measles-cases'
tech: 'Tumult Hype'
thumb: ''
title: 'Measles outbreaks in NSW'
---
