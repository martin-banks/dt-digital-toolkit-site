---
bylines: 'Martin Banks, Irene Sclavos'
capi: '1368577cd3edfb4749cfb6f5a00eaad1'
date: '2019-02-28'
description: 'Custom link bock for Supercoach study guides for each team.'
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2019/NED-0193-supercoach-study-guide-links/dist/prod/index.html'
slug: '/20190228-supercoach-linkblock'
tech: 'JavaScript'
thumb: ''
title: 'SuperCpach study guide link block'
---
