---
bylines: 'Martin Banks, Irene Sclavos'
capi: ''
date: '2018-04-28'
description: "As recognition for rugby league’s greatest-ever players, the NRL Hall of Fame will this year induct six new players. The six champions, who will join the 100 Greats named 10 years ago in the Hall of Fame, will be selected from this enviable list of 25 players."
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2018/0427_nrl_hall_of_fame/_BUILD/PROD/preview.html'
slug: '/20180428-buzz-nrl-picks'
tech: 'JavaScript'
thumb: ''
title: 'Six of the best'
---
