---
bylines: ''
capi: 'cf0b66a3067068e1b3e215a62d3e69f3'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/doctor/index.html'
slug: '/junior-doctor'
tech: 'Jpg'
thumb: ''
title: 'Junior Doctor'
---
