---
bylines: 'Candy Luan'
capi: '6f98131846e3f1eb93a4211ecf757ce2'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/MAFSnow/index.html'
slug: '/mafs-where-are-they-now'
tech: 'Adobe Animate CC'
thumb: ''
title: 'MAFS couples; where are they now'
---
