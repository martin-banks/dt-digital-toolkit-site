---
bylines: 'Candy Luan'
capi: '0ffaa63ef05bf5883ca0a38483d171d4'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/toadsvsfrog/index.html'
slug: '/toads-frogs'
tech: ''
thumb: ''
title: 'The differences between toads and frogs'
---
