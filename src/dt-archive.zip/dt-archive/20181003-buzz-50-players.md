---
bylines: 'Martin Banks, Irene Sclavos'
capi: ''
date: '2018-10-03'
description: ''
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2018/1003-buzz-top50-nrl-moments/dist/PROD/preview.html'
slug: '/20181003-buzz-50-moments'
tech: 'Vue.js'
thumb: ''
title: "Buzz's 50 most dramatic NRL moments of 2018"
---
