---
bylines: ''
capi: '063267d25a36ca1717f1c5d1a22a1948'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/Undercover/index.html  '
slug: '/under-cover'
tech: ''
thumb: ''
title: 'The Undercovers'
---
