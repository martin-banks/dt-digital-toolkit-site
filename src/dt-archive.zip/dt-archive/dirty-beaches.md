---
bylines: 'Fuzz Hamzah'
capi: 'a0bdc92496a0209bca00a76e2a31f4fd'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/poison/index.html'
slug: '/dirty-beaches'
tech: 'Tumult Hype'
thumb: ''
title: 'Dirty beaches'
---
