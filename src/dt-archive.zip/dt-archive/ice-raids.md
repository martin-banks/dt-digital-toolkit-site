---
bylines: ''
capi: '6bf16724ae323164a711e0bdb7ca24a3'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/iceraids/index.html'
slug: '/ice-raids'
tech: ''
thumb: ''
title: 'Ice raids'
---
