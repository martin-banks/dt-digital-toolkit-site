---
bylines: 'Candy Luan'
capi: '818dc22e8a74d07af639e6dcfda0a4e7'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/opaltower/index.html'
slug: '/opal-tower'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Opal tower'
---
