---
bylines: ''
capi: '0e4cee54fa98f3a4d02ba7469f8f64a7'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/gunning/index.html  '
slug: '/gunning-for-a-deal'
tech: ''
thumb: ''
title: 'Gunning for a deal'
---
