---
bylines: 'Candy Luan'
capi: 'd21b9654bf1fb00cabf21879cabfcecd'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/demountables/index.html'
slug: '/classroom-wars'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Classroom wars'
---
