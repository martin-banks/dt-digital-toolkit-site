---
bylines: ''
capi: '438489482194f3657b153f7d96b8a373'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/dams/index.html'
slug: '/sydney-dams'
tech: ''
thumb: ''
title: 'Sydney dams'
---
