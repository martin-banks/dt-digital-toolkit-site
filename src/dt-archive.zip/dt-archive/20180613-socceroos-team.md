---
bylines: 'Martin Banks, Irene Sclavos'
capi: ''
date: '2018-06-13'
description: 'So, the final 23 have been chosen. These are the players entrusted with the task of tackling the greatest tournament on earth and doing Australia proud. Coach Bert van Marwijk has opted for a blend of experience and youth as the men in green and gold prepare for group stage tests against France, Peru and Denmark. Will Tim Cahill prove the talisman at his fourth World Cup or perhaps exciting new-kid-on-the block, Daniel Arzani? Let the action unfold!'
preview: 'https://d2n6ofw4o746cn.cloudfront.net/T3Interactives/2018/0613-worldcup-australia-team/_BUILD/PROD/preview.html'
slug: '/20180613-socceroos-team'
tech: 'JavaScript'
thumb: ''
title: 'Our men on a mission'
---
