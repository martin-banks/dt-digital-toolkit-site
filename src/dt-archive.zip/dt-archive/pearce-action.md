---
bylines: 'Candy Luan'
capi: '7090e9374d39ce082d0ca33168b768c2'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/pearceaction/index.html'
slug: '/pearce-action'
tech: ''
thumb: ''
title: 'A Pearce of teh action'
---
