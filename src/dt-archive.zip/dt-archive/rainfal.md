---
bylines: ''
capi: '54baaf7198cc2408fe77424d1e4549bf'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/rainfall/index.html'
slug: '/rainfall'
tech: 'Jpg'
thumb: ''
title: 'Rainfall'
---
