---
bylines: ''
capi: 'c1c5775433378411a1d23952f2259866'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/WaterTorture/index.html'
slug: '/water-torture'
tech: 'Jpg'
thumb: ''
title: 'Water torture'
---
