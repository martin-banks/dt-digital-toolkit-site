---
bylines: ''
capi: 'F33815dc301a8c1b9f0ffb2d85c9310c'
date: ''
description: ''
preview: ''
slug: '/holdom-confession'
tech: ''
thumb: ''
title: 'Daniel Holdom confession'
---
