---
bylines: 'Candy Luan, Fuzz Hamzah'
capi: '358c91e221e68971b24dfe688edf1946'
date: ''
description: ''
preview: 'https://media.news.com.au/DTinteractive/wind/index.html'
slug: '/strong-winds'
tech: 'Adobe Animate CC'
thumb: ''
title: 'Strong winds'
---
